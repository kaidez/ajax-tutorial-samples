$("#textTarget").load("article.html #author");
