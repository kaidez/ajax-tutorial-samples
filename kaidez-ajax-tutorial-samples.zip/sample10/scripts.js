$("#textTarget").load("articleName.html");
