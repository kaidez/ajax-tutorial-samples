$("#getHTMLFile").click(function(){
  $("#textTarget").load("articleName.html");
});
