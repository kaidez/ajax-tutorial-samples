$.get("articleName.html", function(data) {
  $("#textTarget").html(data);
});
