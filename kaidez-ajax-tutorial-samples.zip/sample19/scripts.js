$("#textTarget").load("article.html")
  .done(function(data) {
    console.log("The file has loaded!");
});
